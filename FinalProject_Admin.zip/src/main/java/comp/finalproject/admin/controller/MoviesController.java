package comp.finalproject.admin.controller;

import comp.finalproject.admin.entity.Movies;
import comp.finalproject.admin.repository.MoviesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Optional;

@Controller
public class MoviesController {

    @Autowired
    private MoviesRepository moviesRepository;

    @GetMapping("/movies")
    public String viewMoviesPage(Model model) {
        List<Movies> movies = moviesRepository.findAll();
        model.addAttribute("movies", movies);
        return "movies";
    }

    @GetMapping("/moviesnew")
    public String showNewMovieForm(Model model) {
        Movies movie = new Movies();
        model.addAttribute("movies", movie);
        return "moviesnew";
    }

    @PostMapping("/moviescreate")
    public String createMovie(@ModelAttribute("movies") Movies movies) {
        moviesRepository.save(movies);
        return "redirect:/movies";
    }
    @RequestMapping(value = "/savemovies", method = RequestMethod.POST)
    public String save(@ModelAttribute("book") Movies movies) {
        moviesRepository.save(movies);

        return "redirect:/movies";
    }


    @GetMapping("/editmovie/{id}")
    public ModelAndView showEditForm(@PathVariable(name = "id") int id) {
        ModelAndView mav = new ModelAndView("moviesedit");
        Movies movie = moviesRepository.findById(id);
        mav.addObject("movies", movie);

        return mav;
    }

    @PostMapping("/moviesupdate")
    public String updateMovie(@ModelAttribute("movies") Movies movies) {
        moviesRepository.save(movies);
        return "redirect:/movies";
    }

    @GetMapping("/moviesdelete/{id}")
    public String deleteMovie(@PathVariable("id") long id) {
        moviesRepository.deleteById(id);
        return "redirect:/movies";
    }

    // Other methods and dependencies...
}
