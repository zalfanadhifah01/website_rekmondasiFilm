package comp.finalproject.admin.repository;
import comp.finalproject.admin.entity.Movies;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface MoviesRepository extends JpaRepository<Movies, Long> {

    List<Movies> findAll();

     Movies findById(int id);

    void deleteById(long id);

    int deleteById(int id);

    Movies save(Movies movies);

}
