package comp.finalproject.admin.service;

import comp.finalproject.admin.dto.UserDto;
import comp.finalproject.admin.entity.User;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.List;

public interface UserService {
    void saveUser(@Valid UserDto userDto);

    User findUserByEmail(String email);

    List<UserDto> findAllUsers();
}